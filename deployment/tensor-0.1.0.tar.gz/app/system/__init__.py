"""General stuff, for use around the whole system."""
from .base_model import BaseEntity
