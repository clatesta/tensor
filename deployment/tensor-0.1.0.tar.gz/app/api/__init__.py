"""__init__.py - Apis."""

from .local import internal_api, external_api
