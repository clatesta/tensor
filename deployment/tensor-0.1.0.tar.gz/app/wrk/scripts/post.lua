local json = require 'rapidjson'

function replay(requests, segment_file)
    for i in string.gmatch(segment_file, "([^\r\n]+)[\r\n]") do
        table.insert(requests, wrk.format(nil, i))
    end
end


init = function(args)
    wrk.method = "POST"
    wrk.body   = "foo=bar&baz=quux"
    wrk.headers["Content-Type"] = "application/x-www-form-urlencoded"
    --  h = json.encode(args)
    --  io.write(h)
    local segment_file = io.read("*a")

    target = args[1]
    local requests = {}
    replay(requests, segment_file)

    req = table.concat(requests)
    req_table = requests
    max_requests = table.getn(req_table)
    -- max_requests = 4
    start_time = socket.gettime()
end

request_count = -1
function request()
    if request_count == max_requests then
      -- Once the last request has been sent stop or start over depending on
      -- the way the command was invoked
        if run_once then
            return
        end
        request_count = 0
    end
    request_count = request_count + 1

    if request_count == 0 then
        -- stupid bug in wrk, the first request is not actually fired
        return req_table[1]
    end
    return req_table[request_count]
end

function round(val, decimal)
    local exp = decimal and 10^decimal or 1
    return math.ceil(val * exp - 0.5) / exp
end

finished_count = 0

-- function delay()
--     return 1000
-- end

stopped = false

response = function()
    finished_count = finished_count + 1
    if finished_count == max_requests and run_once then
        io.write('elapsed time: ' .. socket.gettime() - start_time .. '\n')
        wrk.thread:stop()
    end
end

done = function(summary, latency, requests)
    io.write("------------------------------\n")
    summary["total_errors"] =
        summary.errors.write
            + summary.errors.read
            + summary.errors.status
            + summary.errors.timeout
            + summary.errors.connect

    summary["latency"] =
        {min=latency.min,
         max=latency.max,
         mean=latency.mean,
         stdev=latency.stdev}

    sec = summary.duration * 0.000001

    summary["requests_sec"] = 
        round(summary.requests / sec, 0)

    summary["errors_sec"] = 
        round(summary.total_errors / sec, 0)

    summary["bytes_sec"] = 
        round(summary.bytes / sec, 0)

    summary["kbytes_sec"] = 
      round(summary.bytes_sec / 1000, 2)

    summary["mbytes_sec"] = 
      round(summary.kbytes_sec / 1000, 2)


    s = json.encode(summary)
    io.write('summary: ')
    io.write(s .. "\n")
end
