local json = require 'rapidjson'

function round(val, decimal)
    local exp = decimal and 10^decimal or 1
    return math.ceil(val * exp - 0.5) / exp
end

function done(summary, latency, requests)
    io.write("------------------------------\n")

    summary["total_errors"] =
        summary.errors.write
            + summary.errors.read
            + summary.errors.status
            + summary.errors.timeout
            + summary.errors.connect

    summary["latency"] =
        {min=latency.min,
         max=latency.max,
         mean=latency.mean,
         stdev=latency.stdev}

    distribution = {}
    for _, p in pairs({ 50, 90, 99, 99.999 }) do
        n = latency:percentile(p)
        distribution[string.format("%g%%", p)]= n
    end
    summary["distribution"] = distribution

    sec = summary.duration * 0.000001

    summary["requests_sec"] = 
        round(summary.requests / sec, 0)

    summary["bytes_sec"] = 
        round(summary.bytes / sec, 0)

    s = json.encode(summary)
    io.write('summary: ')
    io.write(s .. "\n")

    io.write("------------------------------\n")
end
