local json = require "rapidjson"

init = function(args)
    requests = json.decode(io.read("*a"))
    request_count = 0
    max_requests = #requests
end

-- function delay()
--    return 2000
-- end

request = function()
    if request_count == max_requests then
        request_count = 1
    end
    request_count = request_count + 1
    return requests[request_count]
end

function round(val, decimal)
    local exp = decimal and 10^decimal or 1
    return math.ceil(val * exp - 0.5) / exp
end

done = function(summary, latency, requests)
    io.write("------------------------------\n")

    summary["total_errors"] =
        summary.errors.write
            + summary.errors.read
            + summary.errors.status
            + summary.errors.timeout
            + summary.errors.connect

    summary["latency"] =
        {min=latency.min,
         max=latency.max,
         mean=latency.mean,
         stdev=latency.stdev}

    sec = summary.duration * 0.000001

    summary["requests_sec"] = 
        round(summary.requests / sec, 1)

    summary["errors_sec"] = 
        round(summary.total_errors / sec, 1)

    summary["bytes_sec"] = 
        round(summary.bytes / sec, 0)

    summary["kbytes_sec"] = 
      round(summary.bytes_sec / 1000, 2)

    summary["mbytes_sec"] = 
      round(summary.kbytes_sec / 1000, 2)

    s = json.encode(summary)
    io.write('summary: ')
    io.write(s .. "\n")
    io.write("------------------------------\n")
end
